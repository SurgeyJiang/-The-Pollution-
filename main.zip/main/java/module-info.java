module com.example.demo {
    requires javafx.controls;
    requires javafx.fxml;

    //requires org.kordamp.bootstrapfx.core;
    //requires jfxrt;
    //requires rt;

    opens com.example.demo to javafx.fxml;
    exports com.example.demo;
    opens com.example.demo.controller to javafx.fxml;
}