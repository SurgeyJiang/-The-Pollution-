package sprite;

import com.example.demo.scene.GameScene;
import javafx.scene.image.Image;
import util.Direction;
import util.kind;

import java.util.HashMap;
import java.util.Map;

public abstract class Role extends Sprite{



    boolean alive = true;
    kind group;
    Direction dir;

    public Role(Image image, double x, double y, double width, double height, GameScene gameScene, Direction dir) {
        super(image, x, y, width, height, gameScene);
        this.dir = dir;
    }

    double speed;
    Map<String,Image> imageMap =  new HashMap<>();

    public Role(Image image, double x, double y, double width, double height, GameScene gameScene, kind group) {
        super(image, x, y, width, height, gameScene);
        this.group = group;
    }



    public  Role(Image image, double x, double y, double width, double height, kind group, Direction dir, GameScene gameScene){
        super( image,x,y,width,height,gameScene);
        this.group = group;
        this.dir = dir;
    }


    public abstract void move();
    //public abstract boolean impackchecking(Sprite sprite);

    public boolean isAlive() {
        return alive;
    }

    public void setAlive(boolean alive) {
        this.alive = alive;
    }
}
