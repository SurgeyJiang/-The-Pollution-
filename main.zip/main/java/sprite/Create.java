package sprite;

import javafx.scene.image.Image;

public class Create extends Sprite{
    public Create( double x, double y) {
        super(new Image("box.png"), x, y,480, 544);
    }
}
