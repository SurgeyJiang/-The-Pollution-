package sprite;

import javafx.scene.image.Image;

public class Background extends Sprite{
    public Background() {
        super(new Image("warground2.jpg"), 0, 0, 1260, 640);
    }
}
