package sprite;

import com.example.demo.scene.GameScene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

public class Explode extends Sprite{
    private int count = 0;
    private Image[] images = new Image[]{
            new Image("LiJiangBulletAttack1.png"),
            new Image("LiJiangBulletAttack2.png"),
            new Image("LiJiangBulletAttack3.png"),
            new Image("LiJiangBulletAttack4.png"),
            new Image("LiJiangBulletAttack5.png"),
            new Image("LiJiangBulletAttack6.png"),
    };

    public Explode(Image image,double x, double y,  GameScene gameScene) {
        super(null,x, y,0,0, gameScene);
    }

    @Override
    public void paint(GraphicsContext graphicsContext){
        if (count>=images.length){
            gameScene.explodes.remove(this);
            return;
        }
        image = images[count];
        double ex = x-image.getWidth()/2;
        double ey = y-image.getHeight()/2;
        graphicsContext.drawImage(image,ex,ey);
        count ++;
    }
}
