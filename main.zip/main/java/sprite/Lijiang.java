package sprite;

import com.example.demo.Director;
import com.example.demo.scene.GameScene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import util.Direction;
import util.kind;

import java.util.List;
import java.util.Random;

public class Lijiang extends Role{

    Direction pdir;
    boolean keyright,keyleft,keyup,keydown;
    double oldx,oldy;
    public static Random random = new Random();

    public Lijiang(double x, double y, double width, double height, kind group, Direction dir, Direction pdir, GameScene gameScene){
        super(null,x, y, 175, 168, group, dir,  gameScene);

        this.pdir = pdir;
        speed = 5;
        if(group.equals(kind.Solider)){
        imageMap.put("right",new Image("LijiangXiaorenRight.png"));
        imageMap.put("left",new Image("LijiangXiaorenLeft.png"));
        imageMap.put("up",new Image("LijiangXiaorenRight.png"));
        imageMap.put("down",new Image("LijiangXiaorenLeft.png"));
    }else {
            imageMap.put("right",new Image("ThePollutedRight.png"));
            imageMap.put("left",new Image("ThePollutedLeft.png"));
            imageMap.put("up",new Image("ThePollutedRight.png"));
            imageMap.put("down",new Image("ThePollutedLeft.png"));
        }
    }

    public void pressed(KeyCode keyCode){
            switch (keyCode){
                case LEFT :keyleft = true;
                    break;
                case RIGHT :keyright = true;
                    break;
                case UP:keyup = true;
                    break;
                case DOWN:keydown = true;
                    break;

            }
            redirect();
    }
    public void released(KeyCode keyCode) {
        switch (keyCode) {
            case G:
                Fire();
                break;
            case LEFT :
                keyleft = false;
                break;
            case RIGHT :
                keyright = false;
                break;
            case UP:keyup = false;
                break;
            case DOWN:keydown = false;
                break;
        }
        redirect();
    }

    public  void redirect(){
        if(keyright && !keyleft&&!keyup&& !keydown) dir = Direction.right;
        else if(keyleft && !keyright&&!keyup&&!keydown) dir = Direction.left;
        else if(keyup && !keyright&& !keyleft&& !keydown) dir = Direction.up;
        else if(keydown && !keyright&& !keyleft&& !keyup) dir = Direction.down;
        else if(!keyleft && !keyright&&!keyup&& !keydown) dir = Direction.stop;
    }


            @Override
            public void move () {
        oldx = x;
        oldy = y;
              switch (dir){
                  case left :
                      x-=speed;
                  break;
                  case right :
                      x+=speed;
                  break;
                  case up :
                      y+=speed;
                  case down :
                      y-=speed;
              }

              if(dir !=Direction.stop){
                  pdir = dir;
              }

              if(x<0) x=0;
              if(y<0) y=0;
              if(x> Director.WIDTH-width-300) x=Director.WIDTH-width-300;
              if(y> Director.HEIGHT-height) x=Director.HEIGHT-height-30;

              if(group.equals(kind.ThePolluted)){
                  int i = random.nextInt(100);
                  switch (i){
                      case 80:
                          Direction d[]= Direction.values();
                          dir = d[random.nextInt(d.length)];
                          break;
                      case 90:
                          Fire();
                          break;
                  }
            }}

        @Override
        public void paint(GraphicsContext graphicsContext){
              if(group.equals(kind.ThePolluted)&&!alive){
                  gameScene.lijiangs.remove(this);
                  return;

              }
            switch (pdir){
                case left :
                    image = imageMap.get("left");
                break;
                case right :
                    image = imageMap.get("right");
                break;
                case down :
                    image = imageMap.get("down");
                    break;
                case up :
                    image = imageMap.get("up");
                    break;

            }
            super.paint(graphicsContext);
            move();
        }

            public void Fire(){
               double bx = x+width/2;
               double by = y+height/4;
               Bullet bullet = new Bullet(bx,by,group,pdir,gameScene);
               gameScene.bullets.add(bullet);
            }

    public boolean impact(Sprite sprite){
        if (sprite !=null &&sprite.equals(this)&&getContour().intersects(sprite.getContour())){
           x = oldx;
           y = oldy;
            return true;
        }

            return false;
}


    public void impact(List<? extends Sprite> sprites){

        for (Sprite sprite:
                sprites  ) {
            impact(sprite);
        }
    }
}





