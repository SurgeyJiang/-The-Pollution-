package sprite;

import com.example.demo.scene.GameScene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import util.Direction;
import util.kind;

import java.util.List;

public class Bullet extends Role{
    public  Bullet(double x, double y, kind kind, Direction dir, GameScene gameScene){
        super(null,x,y,0,0,kind,dir,gameScene);
        speed = 20;
        if(dir.equals(Direction.left )|| dir.equals(Direction.right)){
            width = 22;
            height = 10;
        }
        kind = kind;
        if(kind.equals(kind.Solider)){
            switch (dir){
                case left :
                    image = new Image("lijiangAmmourLeft.png");
                    break;
                case right:
                    image = new Image("lijiangAmmourRight.png");
                    break;
            }
        }//else{
        //switch (dir){
            //case left -> image = new Image("ziyuan/LijiangXiaorenLeft.png");
            //break;
            //case right ->image = new Image("ziyuan/LijiangXiaorenRight.png");
            //break;
        //}
    }
    @Override
    public void move() {
        switch (dir) {
            case left :
                x -= speed;
                    break;

            case right :
                x += speed;
              break;
        }
        //if(x<0) x=0;
        ///if(y<0) y=0;
        //if(x> Director.WIDTH-width-300) x=Director.WIDTH-width-300;
        //if(y> Director.HEIGHT-height) x=Director.HEIGHT-height-30;
       // if (x<0||y<0||x>Director.WIDTH||y>Director.HEIGHT){
            //gameScene.bullets.remove(this);
        }





        @Override
                public void paint(GraphicsContext graphicsContext){
            if(!alive){
                gameScene.bullets.remove(this);
                gameScene.explodes.add(new Explode(null,x,y,gameScene));
                return;
            }
            super.paint(graphicsContext);
            move();
        }


                public boolean impactLijiang(Lijiang lijiang){
                    if (lijiang !=null&&!lijiang.group.equals(this.group)&&getContour().intersects(lijiang.getContour())){
                        lijiang.setAlive(false);
                        alive = false;
                        return true;
                    }

                        return false;
        }

        public void impactLijiang(List<Lijiang>lijiangs){
            for (Lijiang t:
               lijiangs  ) {
                impactLijiang(t);
            }
        }

        public boolean imapctCreate(Create create) {
            if (create!=null&&getContour().intersects(create.getContour())){
                alive = false;
                gameScene.creates.remove(create);
                return  true;
            }

                return false;
            }
            public void impactCreates(List<Create>creates){
                for (Create c: creates
                     ) {
                    imapctCreate(c);
                }
                for (int i = 0; i < creates.size(); i++) {
                    Create create = creates.get(i);
                    imapctCreate(create);

                }
            }
        }



