package util;

public enum Direction {
    left,stop,right,up,down
}
