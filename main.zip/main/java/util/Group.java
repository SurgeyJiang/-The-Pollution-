package util;

public enum Group {
    ThePolluted,Solider
}
