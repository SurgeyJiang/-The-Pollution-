package util;

public enum kind {
    ThePolluted,Solider
}
