package sound;

import java.io.File;

public class SoungEffect {
    public static void main(String[] args)throws Exception,Exception{
        File file = new File("src/main/ziyuan/北京室内男声合唱团 - 亮剑-中国军魂.flac");
        //AddioClip = new audioclip.play;
    }
}




