package com.example.demo;

import com.example.demo.scene.GameOver;
import com.example.demo.scene.GameScene;
import com.example.demo.scene.Index;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Director {

    public static final double WIDTH = 1280,HEIGHT = 640;

    private static Director instance = new Director();
    private Stage stage;
    private GameScene gameScene = new GameScene();

    private Director() {}

    public static Director getInstance() {
        return instance;
    }

    public void init(Stage stage){
        AnchorPane root = new AnchorPane();
        Scene scene = new Scene(root , WIDTH , HEIGHT);
        stage.setTitle("污染");
        stage.getIcons().add(new Image("logo.jpg"));
        stage.setResizable(false);
        stage.setScene(scene);
        stage.setWidth(WIDTH);
        stage.setHeight(HEIGHT);
        this.stage = stage;
        toIndex();
        stage.show();
    }

    public void toIndex() {
        Index.load(stage);
    }

    public void gameOver(boolean success) {
        gameScene.clear(stage);
        GameOver.load(stage,success);
    }

    public void gameStart() {
       gameScene.init(stage);
    }
}
