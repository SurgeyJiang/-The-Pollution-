package com.example.demo.scene;

import com.example.demo.Director;
import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import sprite.*;
import util.Direction;
import util.kind;

import java.util.ArrayList;
import java.util.List;

public class GameScene {
    int i = 0;
    int g = 1;
    private Canvas canvas = new Canvas(Director.WIDTH,Director.HEIGHT);
    private GraphicsContext graphicsContext = canvas.getGraphicsContext2D();

    private  KeyProcess keyProcess = new KeyProcess();
    private Refresh refresh = new Refresh();
    private boolean running = false;

    private Background background = new Background();
    private Lijiang self = null;
    public List<Bullet> bullets = new ArrayList<>();
    public List<Lijiang>lijiangs = new ArrayList<>();
    public List<Explode>explodes = new ArrayList<>();
    public List<Create>creates = new ArrayList<>();

    private void paint(){
        background.paint(graphicsContext);
        self.paint(graphicsContext);
        self.impact(lijiangs);
        self.impact(creates);



        for (int i = 0; i < bullets.size(); i++) {
            Bullet b = bullets.get(i);
            b.paint(graphicsContext);
            b.impactCreates(creates);
            b.impactLijiang(lijiangs);
            b.impactLijiang(self);


        }


        for (int i = 0; i < lijiangs.size(); i++) {
            Lijiang lijiang = lijiangs.get(i);
            lijiang.paint(graphicsContext);
            lijiang.impact(creates);
            lijiang.impact(self);
            lijiang.impact(lijiangs);

        }

        for (int i = 0; i < explodes.size(); i++) {
            Explode e = explodes.get(i);
            e.paint(graphicsContext);
        }

        for (int i = 0; i < creates.size(); i++) {
            Create create = creates.get(i);
            create.paint(graphicsContext);
        }

        graphicsContext.setFill(Color.RED);
        graphicsContext.setFont(new Font(20));
        graphicsContext.fillText("污染体数量"+lijiangs.size(),750,60);
        graphicsContext.fillText("子弹消耗数量"+bullets.size(),750,90);
        graphicsContext.fillText("黎将（角色）",1100,100);
        if (self.isAlive()){
            Director.getInstance().gameStart();
        }else if (lijiangs.isEmpty()){
            Director.getInstance().gameOver(true);

        }

    }



    public  void  init(Stage stage){

        AnchorPane root = new AnchorPane(canvas);
        stage.getScene().setRoot(root);
        stage.getScene().setOnKeyReleased(keyProcess);
        stage.getScene().setOnKeyPressed(keyProcess);
        running = true;
        self = new Lijiang(0,50,175,168, kind.Solider,Direction.stop,Direction.right,this);
        initSprite();
        refresh.start();
        int i = 0;
    }


    private void initSprite(){

        if (i<6){
            i=i+1;
            Lijiang lijiang = new Lijiang(700-i*80,50,0,0, kind.ThePolluted,Direction.stop,Direction.left,this);
            lijiangs.add(lijiang);

        }

        if (g<10) {
            g=g+1;
            Create create1 = new Create(250+i*31,720);
            Create create2 = new Create(250+i*31,720);
            creates.add(create1);
            creates.add(create2);

        }
    }

    public void clear(Stage stage) {

        stage.getScene().removeEventHandler(KeyEvent.KEY_PRESSED,keyProcess);
        stage.getScene().removeEventHandler(KeyEvent.KEY_RELEASED,keyProcess);
        refresh.stop();
        self = null;
        lijiangs.clear();
        bullets.clear();
        creates.clear();
        explodes.clear();
    }

    private class Refresh extends AnimationTimer{
        @Override
        public void handle(long now){
            if (running) {
                paint();
            }
        }
    }

    private class KeyProcess implements EventHandler<KeyEvent>{

        @Override
        public  void handle(KeyEvent event) {
            KeyCode keyCode = event.getCode();
            if (event.getEventType() == KeyEvent.KEY_RELEASED){
                if (keyCode.equals(KeyCode.SPACE)){
                    pauseOrContinue();
                }
                self.released(keyCode);
                if (self!=null)self.released(keyCode);

            }else if(event.getEventType() == KeyEvent.KEY_PRESSED){
                if (self!=null){
                    self.pressed(keyCode);
                }
            }
        }
    }

    public void pauseOrContinue(){
        if(running){
            running = false;
        }else {
            running = true;
        }
    }
}
