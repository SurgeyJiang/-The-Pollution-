package com.example.demo.controller;

import com.example.demo.Director;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;


public class IndexController {

    @FXML
    private ImageView LogoInGame;

    @FXML
    void mouseClickedLogoInGame(MouseEvent event) {
        Director.getInstance().gameStart();
        LogoInGame.setOpacity(0.8);

    }

    @FXML
    void mouseEnteredLogoInGame(MouseEvent event) {
         LogoInGame.setOpacity(0.8);
    }

    @FXML
    void mouseExitedLogoInGame(MouseEvent event) {
        LogoInGame.setOpacity(1);

    }

}

